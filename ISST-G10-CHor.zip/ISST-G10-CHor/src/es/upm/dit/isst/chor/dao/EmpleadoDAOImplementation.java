package es.upm.dit.isst.chor.dao;

import java.util.Collection;

import es.upm.dit.isst.chor.model.Empleado;

public class EmpleadoDAOImplementation implements EmpleadoDAO {

	@Override
	public void create(Empleado empleado) {
		// TODO Auto-generated method stub

	}

	@Override
	public Empleado read(String email) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(Empleado empleado) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(Empleado empleado) {
		// TODO Auto-generated method stub

	}

	@Override
	public Collection<Empleado> readAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Empleado login(String email, String psd) {
		// TODO Auto-generated method stub
		return null;
	}

}
