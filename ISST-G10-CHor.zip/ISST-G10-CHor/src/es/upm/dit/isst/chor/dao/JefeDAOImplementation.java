package es.upm.dit.isst.chor.dao;

import java.util.Collection;

import es.upm.dit.isst.chor.model.Jefe;

public class JefeDAOImplementation implements JefeDAO {

	@Override
	public void create(Jefe jefe) {
		// TODO Auto-generated method stub

	}

	@Override
	public Jefe read(String email) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(Jefe jefe) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(Jefe jefe) {
		// TODO Auto-generated method stub

	}

	@Override
	public Collection<Jefe> readAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Jefe login(String email, String psd) {
		// TODO Auto-generated method stub
		return null;
	}

}
