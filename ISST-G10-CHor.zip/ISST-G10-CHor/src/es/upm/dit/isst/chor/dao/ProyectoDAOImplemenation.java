package es.upm.dit.isst.chor.dao;

import java.util.Collection;

import es.upm.dit.isst.chor.model.Proyecto;

public class ProyectoDAOImplemenation implements ProyectoDAO {

	@Override
	public void create(Proyecto proyecto) {
		// TODO Auto-generated method stub

	}

	@Override
	public Proyecto read(String email) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(Proyecto proyecto) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(Proyecto proyecto) {
		// TODO Auto-generated method stub

	}

	@Override
	public Collection<Proyecto> readAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Proyecto login(String email, String psd) {
		// TODO Auto-generated method stub
		return null;
	}

}
